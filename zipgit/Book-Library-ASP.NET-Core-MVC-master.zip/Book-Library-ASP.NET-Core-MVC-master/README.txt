Book Library demo app.
