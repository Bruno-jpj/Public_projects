﻿namespace BookLibrary.WebServer.Models.DataTables
{
    public class Search
    {
        public string Value { get; set; }
        public bool Regex { get; set; }
    }
}
